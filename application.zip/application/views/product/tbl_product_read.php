<div class='main'>
        <h2 style="margin-top:0px">Tbl_product اطلاعات</h2>
        <table class="table">
	    <tr><td>Code</td><td><?php echo $Code; ?></td></tr>
	    <tr><td>Title</td><td><?php echo $Title; ?></td></tr>
	    <tr><td>Price</td><td><?php echo $Price; ?></td></tr>
	    <tr><td>Photo</td><td><?php echo $Photo; ?></td></tr>
	    <tr><td>Discript</td><td><?php echo $Discript; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('productcontroller') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>
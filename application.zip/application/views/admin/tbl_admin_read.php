<div class='main'>
        <h2 style="margin-top:0px">Tbl_admin اطلاعات</h2>
        <table class="table">
	    <tr><td>userName</td><td><?php echo $userName; ?></td></tr>
	    <tr><td>Password</td><td><?php echo $Password; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('admincontroller') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>
<div class='main'>
        <h2 style="margin-top:0px">Tbl_category اطلاعات</h2>
        <table class="table">
	    <tr><td>Title</td><td><?php echo $Title; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('categorycontroller') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>
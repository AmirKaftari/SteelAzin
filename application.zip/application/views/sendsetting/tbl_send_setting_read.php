<div class='main'>
        <h2 style="margin-top:0px">Tbl_send_setting اطلاعات</h2>
        <table class="table">
	    <tr><td>Type</td><td><?php echo $Type; ?></td></tr>
	    <tr><td>State</td><td><?php echo $State; ?></td></tr>
	    <tr><td>City</td><td><?php echo $City; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('sendsetting') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>
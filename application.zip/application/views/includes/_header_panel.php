    <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/bootstrap.rtl.css') ?>" />
    <link rel="stylesheet" href="<?php echo base_url('') ?>assets/panel/css/main.css" />
    <link rel="stylesheet" href="<?php echo base_url('') ?>assets/panel/css/theme.css" />
    <link rel="stylesheet" href="<?php echo base_url('') ?>assets/panel/css/MoneAdmin.css" />
    <link rel="stylesheet" href="<?php echo base_url('') ?>assets/assets/fontawesome/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/parsley.css') ?>" />
    <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/bootstrap-fileupload.min.css') ?>" />
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" />

<div class="container">

    <!--  ==========  -->
    <!--  = Title =  -->
    <!--  ==========  -->
    <div class="row">
        <div class="span12">
            <div class="main-titles center-align">
                <h2 class="title">
                    <span class="clickable icon-chevron-right" id="tweetsRight"></span> &nbsp;&nbsp;&nbsp;
                    <span class="light">آخرین</span> خبر ها &nbsp;&nbsp;&nbsp;
                    <span class="clickable icon-chevron-left" id="tweetsLeft"></span>
                </h2>
            </div>
        </div>
    </div> <!-- /title -->

    <!--  ==========  -->
    <!--  = News content =  -->
    <!--  ==========  -->
    <div class="row">
        <div class="span12">
            <div class="carouFredSel" data-nav="tweets" data-autoplay="false">


                <!--  ==========  -->
                <!--  = Slide =  -->
                <!--  ==========  -->
                <div class="slide">
                    <div class="row">
                        <div class="span6">
                            <div class="news-item">
                                <div class="published">12 بهمن 1392</div>
                                <h6><a href="#">عنوان خبر شما</a></h6>
                                <p>در این قسمت میتوانید خبر خود را بنویسید. این یک نوشته ی آزمایشی است که صرفا برای پر کردن این بخش به کار رفته و جنبه ی دیگری ندارد. شما میتوانید این ناحیه را با محتوای دلخواه خود پر کنید.</p>
                            </div>
                        </div>
                        <div class="span6">
                            <div class="news-item">
                                <div class="published">15 بهمن 1392</div>
                                <h6><a href="#">یک خبر جالب دیگر</a></h6>
                                <p>در این قسمت میتوانید خبر خود را بنویسید. این یک نوشته ی آزمایشی است که صرفا برای پر کردن این بخش به کار رفته و جنبه ی دیگری ندارد. شما میتوانید این ناحیه را با محتوای دلخواه خود پر کنید.</p>
                            </div>
                        </div>
                    </div>
                </div> <!-- /slide -->


                <!--  ==========  -->
                <!--  = Slide =  -->
                <!--  ==========  -->
                <div class="slide">
                    <div class="row">
                        <div class="span6">
                            <div class="news-item">
                                <div class="published">12 بهمن 1392</div>
                                <h6><a href="#">عنوان خبر شما</a></h6>
                                <p>در این قسمت میتوانید خبر خود را بنویسید. این یک نوشته ی آزمایشی است که صرفا برای پر کردن این بخش به کار رفته و جنبه ی دیگری ندارد. شما میتوانید این ناحیه را با محتوای دلخواه خود پر کنید.</p>
                            </div>
                        </div>
                        <div class="span6">
                            <div class="news-item">
                                <div class="published">15 بهمن 1392</div>
                                <h6><a href="#">یک خبر جالب دیگر</a></h6>
                                <p>در این قسمت میتوانید خبر خود را بنویسید. این یک نوشته ی آزمایشی است که صرفا برای پر کردن این بخش به کار رفته و جنبه ی دیگری ندارد. شما میتوانید این ناحیه را با محتوای دلخواه خود پر کنید.</p>
                            </div>
                        </div>
                    </div>
                </div> <!-- /slide -->

            </div>
        </div>
    </div> <!-- /news content -->
</div>
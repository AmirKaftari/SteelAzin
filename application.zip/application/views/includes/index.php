﻿<div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title">دسترسی سریع...</h3>
    </div>
    <div class="panel-body" align="center">
    	<div class="row" >

            <div class="col-xs-6 col-md-2">
                <a href="#" class="thumbnail">
سفارشات<img src="<?php echo base_url('assets/images/ICO/orders.png') ?>" alt="">
                </a>

            </div>

            <div class="col-xs-6 col-md-2">

                <a href="#" class="thumbnail">
                    سفارشات معلق<img src="<?php echo base_url('assets/images/ICO/orders_suspend.png') ?>" alt="">
                </a>

            </div>

            <div class="col-xs-6 col-md-2">

                <a href="#" class="thumbnail">
                    سفارشات ارسالی<img src="<?php echo base_url('assets/images/ICO/Transport.png') ?>" alt="">
                </a>

            </div>
              
              <div class="col-xs-6 col-md-2">

                <a href="<?php echo base_url('Productcontroller'); ?>" class="thumbnail">
ثبت محصول جدید<img src="<?php echo base_url('assets/images/ICO/new_product.png') ?>" alt="">
                </a>

              </div>
              
              <div class="col-xs-6 col-md-2">
                
                <a href="#" class="thumbnail">
گزارش گیری ماهانه<img src="<?php echo base_url('assets/images/ICO/reports_mounth.png') ?>" alt="">
                </a>
                
              </div>
              
              <div class="col-xs-6 col-md-2">
                
                <a href="#" class="thumbnail">
گزارش گیری سالانه<img src="<?php echo base_url('assets/images/ICO/Bag.png') ?>" alt="">
                </a>
                
              </div>

		</div>
    </div>
</div>
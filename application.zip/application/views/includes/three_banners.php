<div class="row">
    <div class="span12">
        <div class="push-up over-slider blocks-spacer">

            <!--  ==========  -->
            <!--  = Three Banners =  -->
            <!--  ==========  -->
            <div class="row">
                <div class="span4">
                    <a href="#" class="btn btn-block banner">
                        <span class="title"><span class="light">فروش</span> تابستانی</span>
                        <em>تا 20٪ تخفیف روی محصولات</em>
                    </a>
                </div>
                <div class="span4">
                    <a href="#" class="btn btn-block colored banner">
                        <span class="title"><span class="light">ارسال</span> رایگان</span>
                        <em>برای خرید های بیش از 69000 تومان</em>
                    </a>
                </div>
                <div class="span4">
                    <a href="#" class="btn btn-block banner">
                        <span class="title"><span class="light">محصولات</span> جدید</span>
                        <em>از محصولات جدید دیدن کنید.</em>
                    </a>
                </div>
            </div> <!-- /three banners -->
        </div>
    </div>
</div>
<div class='main'>
        <h2 style="margin-top:0px">Tbl_user اطلاعات</h2>
        <table class="table">
	    <tr><td>Fullname</td><td><?php echo $Fullname; ?></td></tr>
	    <tr><td>Name</td><td><?php echo $Name; ?></td></tr>
	    <tr><td>Lastname</td><td><?php echo $Lastname; ?></td></tr>
	    <tr><td>Birthday</td><td><?php echo $Birthday; ?></td></tr>
	    <tr><td>Gender</td><td><?php echo $Gender; ?></td></tr>
	    <tr><td>Nationalcode</td><td><?php echo $Nationalcode; ?></td></tr>
	    <tr><td>IdentityNumber</td><td><?php echo $IdentityNumber; ?></td></tr>
	    <tr><td>State</td><td><?php echo $State; ?></td></tr>
	    <tr><td>City</td><td><?php echo $City; ?></td></tr>
	    <tr><td>District</td><td><?php echo $District; ?></td></tr>
	    <tr><td>Phone</td><td><?php echo $Phone; ?></td></tr>
	    <tr><td>CellPhone</td><td><?php echo $CellPhone; ?></td></tr>
	    <tr><td>CodePost</td><td><?php echo $CodePost; ?></td></tr>
	    <tr><td>Address</td><td><?php echo $Address; ?></td></tr>
	    <tr><td>Username</td><td><?php echo $Username; ?></td></tr>
	    <tr><td>Password</td><td><?php echo $Password; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $Email; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('usercontroller') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>
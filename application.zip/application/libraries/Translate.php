<?php

/**
 * Created by PhpStorm.
 * User: Programmer
 * Date: 07/11/2016
 * Time: 08:44 PM
 */
class Translate
{
    const Welcome = "خوش آمدید";
    const UnValidUser = 'نام کاربری یا رمز عبور اشتباه است!';
    const InsertAccountInfo = "لطفا نام کاربری و رمز عبور را وارد نمایید!";
    const Username = "نام کاربری";
    const Password = "رمز عبور";

    const ListProducts = "لیست محصولات";
}
<?php

/**
 * Created by PhpStorm.
 * User: Programmer
 * Date: 07/11/2016
 * Time: 08:44 PM
 */
class Translate
{
    const Welcome = "خوش آمدید";
    const UnValidUser = 'نام کاربری یا رمز عبور اشتباه است!';
    const InsertAccountInfo = "لطفا اطلاعات درخواستی را پر نمایید!";
    const Username = "نام کاربری";
    const Password = "رمز عبور";
    const successRegister = 'ثبت نام شما با موفقیت انجام شد!';
    const notUniqueUsername = 'این نام کاربری در سیستم قبلا ثبت شده است!';
    const UsernameAndEmail = 'نام کاربری یا پست الکترونیکی';
    const RequireField = 'درج این فیلد اجباری است!';
    const ListProducts = "لیست محصولات";
}